﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MongoDB.Bson;
using MongoDB.Driver;

namespace CVPlatforma
{
    public partial class StudentForm : Form
    {
        public MongoClient client;
        public Student student;
        public StudentForm()
        {
            InitializeComponent();
            client = new MongoClient("mongodb://localhost:27017");
        }

        private void prikazi_konkurse_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Molimo vas odaberite tip pretrage konkursa.");
            }
            else
            {
                string pom = comboBox1.SelectedItem.ToString();

                var db = client.GetDatabase("posao");
                var collection = db.GetCollection<Konkurs>("konkurs");
                var collection1 = db.GetCollection<Kompanija>("kompanija");
                var filter = new BsonDocument();
                var result = collection.Find(filter).ToList();

                if (String.Equals(pom, "PRAKSA"))
                {

                    var filter2 = Builders<Konkurs>.Filter.Eq("tip", pom);
                    var result2 = collection.Find(filter2).ToList();
                    if (result2.Count != 0)
                    {
                        foreach (Konkurs k in result2)
                        {
                            ListViewItem item = new ListViewItem(new string[] { k.pocetak, k.tip
                        , k.radnoMesto, k.opis, k.obrazovanje, k.zahtev, k._id});
                            listView1.Items.Add(item);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Nema konkursa za odabrani tip.");
                    }
                }
                else if (String.Equals(pom, "POSAO NA ODREDJENO"))
                {

                    var filter2 = Builders<Konkurs>.Filter.Eq("tip", pom);
                    var result2 = collection.Find(filter2).ToList();
                    if (result2.Count != 0)
                    {
                        foreach (Konkurs k in result2)
                        {

                            ListViewItem item = new ListViewItem(new string[] { k.pocetak, k.tip
                        , k.radnoMesto, k.opis, k.obrazovanje, k.zahtev,k._id});
                            listView1.Items.Add(item);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Nema konkursa za odabrani tip.");
                    }
                }
                else if (String.Equals(pom, "POSAO NA NEODREDJENO"))
                {

                    var filter2 = Builders<Konkurs>.Filter.Eq("tip", pom);
                    var result2 = collection.Find(filter2).ToList();
                    if (result2.Count != 0)
                    {
                        foreach (Konkurs k in result2)
                        {

                            ListViewItem item = new ListViewItem(new string[] { k.pocetak, k.tip
                        , k.radnoMesto, k.opis, k.obrazovanje, k.zahtev,k._id});
                            listView1.Items.Add(item);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Nema konkursa za odabrani tip.");
                    }
                }
                else
                {
                    if (result.Count != 0)
                    {
                        foreach (Konkurs k in result)
                        {

                            ListViewItem item = new ListViewItem(new string[] { k.pocetak, k.tip
                        , k.radnoMesto, k.opis, k.obrazovanje, k.zahtev,k._id});
                            listView1.Items.Add(item);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Nema konkursa.");
                    }
                }
            }
            
        }
       
        private void prijava_Click(object sender, EventArgs e)
        {
            bool prijava=false; 
            if (listView1.SelectedItems.Count<=0)
            {
                MessageBox.Show("Molimo vas odaberite konkurs za koji zelite da se prijavite.");
            }
            else
            {
                string pom = listView1.SelectedItems[0].SubItems[6].Text;
                var db = client.GetDatabase("posao");
                var collection = db.GetCollection<Student>("student");
                var collection1 = db.GetCollection<Konkurs>("konkurs");
                var collection2 = db.GetCollection<CV>("cv");
                var filter = Builders<Student>.Filter.Eq("korisnickoIme", student.korisnickoIme);
                var result = collection.Find(filter).ToList();
                if (result.Count != 0)
                {
                    var filter1 = Builders<CV>.Filter.Eq("studentId", result[0]._id);
                    var result1 = collection2.Find(filter1).ToList();
                    if (result1.Count != 0)
                    {
                        var filter2 = Builders<Konkurs>.Filter.Eq("_id", pom);
                        var result2 = collection1.Find(filter2).ToList();
                        var array = new BsonArray();
                        if (result2[0].cvId != null)
                        {

                           
                            if (result2[0].cvId != null)
                            {
                                foreach (var n in result2[0].cvId)
                                {
                                    if (n.Equals(result[0]._id))
                                    {
                                        prijava = true;
                                    }
                                    else
                                    {
                                        array.Add(new BsonString(n));
                                    }
                                }
                            }
                            if (prijava == false)
                            {

                                array.Add(new BsonString(result1[0].studentId));
                                var update = new BsonDocument { { "$set", new BsonDocument { { "cvId", array } } } };

                                collection1.UpdateOne(filter2, update);
                                MessageBox.Show("Uspesno ste se prijavili na konkurs.");
                            }
                            else
                            {
                                MessageBox.Show("Vec ste prijavljeni na ovaj konkurs.");
                            }
                        }
                        else
                        {
                            array.Add(new BsonString(result1[0].studentId));
                            var update = new BsonDocument { { "$set", new BsonDocument { { "cvId", array } } } };

                            collection1.UpdateOne(filter2, update);
                            MessageBox.Show("Uspesno ste se prijavili na konkurs.");
                        }
                        
                    }
                }
            }
        }

        private void prikazi_profil_Click(object sender, EventArgs e)
        {
            PrikazProfilaStudenta p = new PrikazProfilaStudenta();
            p.student = student;
            p.client = client;
            p.Show();
        }

        private void prikazi_cv_Click(object sender, EventArgs e)
        {

        }

        private void dodaj_cv_Click(object sender, EventArgs e)
        {

        }

        private void StudentForm_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
