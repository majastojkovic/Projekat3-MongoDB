﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace CVPlatforma
{
    public partial class PrikazProfilaStudenta : Form
    {
        public MongoClient client;
        public Student student;
        public PrikazProfilaStudenta()
        {
            InitializeComponent();
            MongoClient client = new MongoClient("mongodb://localhost:27017");
            txtSifra.UseSystemPasswordChar = true;

        }

        private void PrikazProfilaStudenta_Load(object sender, EventArgs e)
        {
            txtIme.Text = student.imePrezime;
            txtKorisnicko.Text = student.korisnickoIme;
            txtEmail.Text = student.email;
            txtSifra.Text = student.sifra;


        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void IzmeniProfil_Click(object sender, EventArgs e)
        {
            string imePrezime = txtIme.Text;
            string korisnickoIme = txtKorisnicko.Text;
            string email = txtEmail.Text;
            string sifra = txtSifra.Text;

            var db = client.GetDatabase("posao");
            var collection = db.GetCollection<Student>("student");
                var filter = Builders<Student>.Filter.Eq("korisnickoIme", student.korisnickoIme);
                var result = collection.Find(filter).ToList();
                if (student.korisnickoIme != korisnickoIme)
                {
                    var filter1 = Builders<Student>.Filter.Eq("korisnickoIme", korisnickoIme);
                    var result1 = collection.Find(filter1).ToList();
                    if (result1.Count == 0)
                    {
                        var st = new Student(result[0]._id, imePrezime, korisnickoIme, email, sifra);
                        var update = new BsonDocument { { "$set", st.ToBsonDocument() } };
                        collection.UpdateOne(filter, update);
                    MessageBox.Show("Uspesno ste izmenili podatke.");
                        
                    }
                    else
                    {
                    MessageBox.Show("Korisnicko ime je zauzeto.");
                    }
                }
                else
                {

                    var st = new Student(result[0]._id, imePrezime, korisnickoIme, email, sifra);
                    var update = new BsonDocument { { "$set", st.ToBsonDocument() } };
                    collection.UpdateOne(filter, update);
                    MessageBox.Show("Uspesno ste izmenili podatke.");

            }

            
        }

        private void dodajCV_Click(object sender, EventArgs e)
        {
            var db = client.GetDatabase("posao");
            var collection = db.GetCollection<Student>("student");
            var collection1 = db.GetCollection<CV>("cv");
            var filter = Builders<Student>.Filter.Eq("korisnickoIme", student.korisnickoIme);
            var result = collection.Find(filter).ToList();

            if (result.Count != 0)
            {
                var filter1 = Builders<CV>.Filter.Eq("studentId", student._id);
                var result1 = collection1.Find(filter1).ToList();
                if(result1.Count==0)
                {
                    DodajCV d = new DodajCV();
                    d.student = student;
                    d.client = client;
                    d.Show();
                }
                else
                {
                    MessageBox.Show("Vec imate CV.");
                }
            }
            
           
        }

        private void prikaziCV_Click(object sender, EventArgs e)
        {
            PrikaziCV d = new PrikaziCV();
            d.student = student;
            d.client = client;
            d.Show();
        }
    }
}
