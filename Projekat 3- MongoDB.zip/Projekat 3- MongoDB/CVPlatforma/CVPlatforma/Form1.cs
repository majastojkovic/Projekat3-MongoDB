﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MongoDB.Driver;
using MongoDB.Bson;

namespace CVPlatforma
{
    public partial class Form1 : Form
    {
       
        MongoClient client;
        public Form1()
        {
            InitializeComponent();
            client = new MongoClient("mongodb://localhost:27017");
            textBoxSifra.UseSystemPasswordChar = true;

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            RegistracijaKompanija r = new RegistracijaKompanija();
            r.ShowDialog();
            this.Close();

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            
            RegistracijaStudent r = new RegistracijaStudent();
            r.ShowDialog();
            this.Close();
        }

        private void prijavi_se_Click(object sender, EventArgs e)
        {
            string email = textBoxEmail.Text;
            string sifra = textBoxSifra.Text;

           
            var db = client.GetDatabase("posao");
            var collection = db.GetCollection<Kompanija>("kompanija");
            var filter = Builders<Kompanija>.Filter.Eq("email", email);
            var result = collection.Find(filter).ToList();
            if(result.Count !=0)
            {
                if(result[0].sifra == sifra)
                {
                    KompanijaForm k = new KompanijaForm();
                    k.client = client;
                    k.kompanija = result[0];
                    k.Show();
                }
                else
                {
                    MessageBox.Show("Molimo unesite ispravne podatke");
                }
            }
            else
            {

                var collection1 = db.GetCollection<Student>("student");
                var filter1 = Builders<Student>.Filter.Eq("email", email);
                var result1 = collection1.Find(filter1).ToList();

                if (result1.Count != 0)
                {
                    if (result1[0].sifra == sifra)
                    {

                        StudentForm s = new StudentForm();
                        s.client = client;
                        s.student = result1[0];
                        s.Show();
                    }
                }
                else
                {
                    MessageBox.Show("Molimo unesite ispravne podatke");
                }

            }


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MongoClient client = new MongoClient();
            var db = client.GetDatabase("posao");
            if(db==null)
            {
                MessageBox.Show("Greska prilikom konekcije");
            }
        }

     /*   private void button1_Click(object sender, EventArgs e)
        {
            var db = client.GetDatabase("posao");
            var collection = db.GetCollection<Konkurs>("konkurs");
            var filter = new BsonDocument();
            var result = collection.Find(filter).ToList();
            MessageBox.Show(result[0].idKompanije.ToString());
        }*/
      
    }
}
