﻿namespace CVPlatforma
{
    partial class DodajKonkurs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxPocetakKonkursa = new System.Windows.Forms.TextBox();
            this.textBoxTip = new System.Windows.Forms.TextBox();
            this.textBoxRadnoMesto = new System.Windows.Forms.TextBox();
            this.textBoxOpis = new System.Windows.Forms.TextBox();
            this.dodaj_konkurs = new System.Windows.Forms.Button();
            this.textBoxObrazovanje = new System.Windows.Forms.RichTextBox();
            this.textBoxZahtevi = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(37, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Početak konkursa:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(86, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tip:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(55, 162);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 18);
            this.label4.TabIndex = 3;
            this.label4.Text = "Radno mesto:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(86, 219);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 18);
            this.label5.TabIndex = 4;
            this.label5.Text = "Opis:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(55, 272);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 18);
            this.label6.TabIndex = 5;
            this.label6.Text = "Obrazovanje:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(78, 353);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 18);
            this.label7.TabIndex = 6;
            this.label7.Text = "Zahtevi:";
            // 
            // textBoxPocetakKonkursa
            // 
            this.textBoxPocetakKonkursa.Location = new System.Drawing.Point(216, 66);
            this.textBoxPocetakKonkursa.Name = "textBoxPocetakKonkursa";
            this.textBoxPocetakKonkursa.Size = new System.Drawing.Size(188, 22);
            this.textBoxPocetakKonkursa.TabIndex = 8;
            // 
            // textBoxTip
            // 
            this.textBoxTip.Location = new System.Drawing.Point(216, 111);
            this.textBoxTip.Name = "textBoxTip";
            this.textBoxTip.Size = new System.Drawing.Size(188, 22);
            this.textBoxTip.TabIndex = 9;
            // 
            // textBoxRadnoMesto
            // 
            this.textBoxRadnoMesto.Location = new System.Drawing.Point(216, 162);
            this.textBoxRadnoMesto.Name = "textBoxRadnoMesto";
            this.textBoxRadnoMesto.Size = new System.Drawing.Size(188, 22);
            this.textBoxRadnoMesto.TabIndex = 11;
            // 
            // textBoxOpis
            // 
            this.textBoxOpis.Location = new System.Drawing.Point(216, 212);
            this.textBoxOpis.Name = "textBoxOpis";
            this.textBoxOpis.Size = new System.Drawing.Size(188, 22);
            this.textBoxOpis.TabIndex = 13;
            // 
            // dodaj_konkurs
            // 
            this.dodaj_konkurs.BackColor = System.Drawing.SystemColors.HotTrack;
            this.dodaj_konkurs.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dodaj_konkurs.Location = new System.Drawing.Point(143, 427);
            this.dodaj_konkurs.Name = "dodaj_konkurs";
            this.dodaj_konkurs.Size = new System.Drawing.Size(172, 52);
            this.dodaj_konkurs.TabIndex = 15;
            this.dodaj_konkurs.Text = "Dodaj konkurs";
            this.dodaj_konkurs.UseVisualStyleBackColor = false;
            this.dodaj_konkurs.Click += new System.EventHandler(this.dodaj_konkurs_Click);
            // 
            // textBoxObrazovanje
            // 
            this.textBoxObrazovanje.Location = new System.Drawing.Point(216, 261);
            this.textBoxObrazovanje.Name = "textBoxObrazovanje";
            this.textBoxObrazovanje.Size = new System.Drawing.Size(188, 52);
            this.textBoxObrazovanje.TabIndex = 16;
            this.textBoxObrazovanje.Text = "";
            // 
            // textBoxZahtevi
            // 
            this.textBoxZahtevi.Location = new System.Drawing.Point(214, 338);
            this.textBoxZahtevi.Name = "textBoxZahtevi";
            this.textBoxZahtevi.Size = new System.Drawing.Size(188, 53);
            this.textBoxZahtevi.TabIndex = 17;
            this.textBoxZahtevi.Text = "";
            // 
            // DodajKonkurs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(510, 526);
            this.Controls.Add(this.textBoxZahtevi);
            this.Controls.Add(this.textBoxObrazovanje);
            this.Controls.Add(this.dodaj_konkurs);
            this.Controls.Add(this.textBoxOpis);
            this.Controls.Add(this.textBoxRadnoMesto);
            this.Controls.Add(this.textBoxTip);
            this.Controls.Add(this.textBoxPocetakKonkursa);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "DodajKonkurs";
            this.Text = "DodajKonkurs";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxPocetakKonkursa;
        private System.Windows.Forms.TextBox textBoxTip;
        private System.Windows.Forms.TextBox textBoxRadnoMesto;
        private System.Windows.Forms.TextBox textBoxOpis;
        private System.Windows.Forms.Button dodaj_konkurs;
        private System.Windows.Forms.RichTextBox textBoxObrazovanje;
        private System.Windows.Forms.RichTextBox textBoxZahtevi;
    }
}