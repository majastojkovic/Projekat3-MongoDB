﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace CVPlatforma
{
    public partial class DodajCV : Form
    {
        public MongoClient client;
        public Student student;

        public DodajCV()
        {
            InitializeComponent();
            client = new MongoClient("mongodb://localhost:27017");
        }

        private void DodajCV_Load(object sender, EventArgs e)
        {

        }

        private void Dodaj_Click(object sender, EventArgs e)
        {
            var db = client.GetDatabase("posao");
            var collection = db.GetCollection<Student>("student");
            var collection1 = db.GetCollection<CV>("cv");
            var filter = Builders<Student>.Filter.Eq("korisnickoIme", student.korisnickoIme);
            var result = collection.Find(filter).ToList();
            string[] obrazovanje = txtObrazovanje.Text.Split(',');
            string[] vestine = txtVestine.Text.Split(',');
            if (result.Count != 0)
            {
                string id = ObjectId.GenerateNewId().ToString();
                var cv = new CV(id, result[0]._id, txtPunoIme.Text, txtDatumRodj.Text, txtAdresa.Text, txtEmail.Text, txtTelefon.Text, obrazovanje, vestine);
                collection1.InsertOne(cv);
            }
            MessageBox.Show("Uspesno ste dodali CV.");
            this.Close();
        }
    }
}
