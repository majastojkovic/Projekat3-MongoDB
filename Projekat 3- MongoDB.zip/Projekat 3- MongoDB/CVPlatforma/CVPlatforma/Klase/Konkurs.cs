﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
namespace CVPlatforma
{
    public class Konkurs
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string _id { get; set; }
        public string idKompanije { get; set; }
        public string pocetak { get; set; }// datum postavljanja konkursa
        public string tip { get; set; }
        public string radnoMesto { get; set; } // radno mesto
        public string opis { get; set; }
        public string obrazovanje { get; set; }
        public string zahtev { get; set; }
        public string[] cvId { get; set; }


        public Konkurs(string _id, string idKompanije, string pocetak, string tip, string radnoMesto, string opis, string obrazovanje, string zahtevi)
        {
            this._id = _id;
            this.idKompanije = idKompanije;
            this.pocetak = pocetak;
            this.tip = tip;
            this.radnoMesto = radnoMesto;
            this.opis = opis;
            this.obrazovanje = obrazovanje;
            this.zahtev = zahtevi;
        }
      }
}
