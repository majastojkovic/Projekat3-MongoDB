﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace CVPlatforma
{
    public class CV
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string _id { get; set; }
        public string studentId { get; set; }
        public string[] vestine { get; set; }
        public LicneInformacije licneInformacije { get; set; }
        public string[] obrazovanje { get; set; }
       

        public CV(string _id, string studentId, string punoIme, string datumRodjenja, string adresa, string email, string telefon, string[] obrazovanje, string[] vestine)
        {
            this._id = _id;
            this.studentId = studentId;
            this.licneInformacije = new LicneInformacije(punoIme, datumRodjenja, adresa, email, telefon);
            this.obrazovanje = obrazovanje;
            this.vestine = vestine;
        }
       

    }
    public class LicneInformacije
    {
        public string punoIme { get; set; }
        public string datumRodjenja { get; set; }
        public string adresa { get; set; }
        public string email { get; set; }
        public string telefon { get; set; }

        public LicneInformacije(string punoIme, string datumRodjenja, string adresa, string email, string telefon)
        {
            this.punoIme = punoIme;
            this.datumRodjenja = datumRodjenja;
            this.adresa = adresa;
            this.email = email;
            this.telefon = telefon;
        }
       
    }
  

}
