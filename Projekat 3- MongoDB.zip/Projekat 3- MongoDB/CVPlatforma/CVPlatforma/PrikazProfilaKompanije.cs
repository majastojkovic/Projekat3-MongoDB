﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MongoDB.Bson;
using MongoDB.Driver;

namespace CVPlatforma
{
    public partial class PrikazProfilaKompanije : Form
    {
        public Kompanija kompanija;
        public MongoClient client;

        public PrikazProfilaKompanije()
        {
            InitializeComponent();
            MongoClient client = new MongoClient("mongodb://localhost:27017");
            txtSifra.UseSystemPasswordChar = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string imePrezime = txtIme.Text;
            string adresa = txtAdresa.Text;
            string telefon = txtTelefon.Text;
            string email = txtEmail.Text;
            string sifra = txtSifra.Text;

            var db = client.GetDatabase("posao");
            var collection = db.GetCollection<Kompanija>("kompanija");
            var filter = Builders<Kompanija>.Filter.Eq("email", kompanija.email);
            var result = collection.Find(filter).ToList();
            if (kompanija.email != email)
            {
                var filter1 = Builders<Kompanija>.Filter.Eq("email", email);
                var result1 = collection.Find(filter1).ToList();
                if (result1.Count == 0)
                {
                    var kom = new Kompanija(result[0]._id, imePrezime,adresa,telefon,email,sifra);
                    var update = new BsonDocument { { "$set", kom.ToBsonDocument() } };
                    collection.UpdateOne(filter, update);
                    MessageBox.Show("Uspesno ste izmenili podatke.");

                }
                else
                {
                    MessageBox.Show("Korisnicko ime je zauzeto.");
                }
            }
            else
            {

                var kom = new Kompanija(result[0]._id, imePrezime, adresa, telefon, email, sifra);
                var update = new BsonDocument { { "$set", kom.ToBsonDocument() } };
                collection.UpdateOne(filter, update);
                MessageBox.Show("Uspesno ste izmenili podatke.");

            }


        }

        private void PrikazProfilaKompanije_Load(object sender, EventArgs e)
        {
            txtIme.Text = kompanija.ime;
            txtAdresa.Text = kompanija.adresa;
            txtTelefon.Text = kompanija.telefon;
            txtEmail.Text = kompanija.email;
            txtSifra.Text = kompanija.sifra;
        }

        private void Ime_Click(object sender, EventArgs e)
        {

        }
    }
}
