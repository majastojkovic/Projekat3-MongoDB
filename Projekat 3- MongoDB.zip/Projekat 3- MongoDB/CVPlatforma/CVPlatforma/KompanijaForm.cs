﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MongoDB.Bson;
using MongoDB.Driver;

namespace CVPlatforma
{
    public partial class KompanijaForm : Form
    {
        public Kompanija kompanija;
        public MongoClient client;
        

        public KompanijaForm()
        {
            InitializeComponent();
             client = new MongoClient("mongodb://localhost:27017");
        }

        private void KompanijaForm_Load(object sender, EventArgs e)
        {

        }

        private void prikazi_profil_Click(object sender, EventArgs e)
        {
            PrikazProfilaKompanije p = new PrikazProfilaKompanije();
            p.client = client;
            p.kompanija = kompanija;
            p.Show();
        }

        private void dodaj_konkurs_Click(object sender, EventArgs e)
        {
            DodajKonkurs d = new DodajKonkurs();
            d.client = client;
            d.kompanija = kompanija;
            d.Show();
        }

        private void pretrazi_konkurse_Click(object sender, EventArgs e)
        {

            var db = client.GetDatabase("posao");
            var collection = db.GetCollection<Kompanija>("kompanija");
            var collection1 = db.GetCollection<Konkurs>("konkurs");

            var filter = Builders<Kompanija>.Filter.Eq("email", kompanija.email);
            var result = collection.Find(filter).ToList();


            if (result.Count != 0)
            {
                var filter1 = Builders<Konkurs>.Filter.Eq("idKompanije", kompanija._id);
                var result1 = collection1.Find(filter1).ToList();

                if (result1.Count != 0)
                {

                    foreach (Konkurs k in result1)
                    {

                        ListViewItem item = new ListViewItem(new string[] { k.pocetak, k.tip
                        , k.radnoMesto, k.opis, k.obrazovanje, k.zahtev, k._id,k.idKompanije});
                        listView1.Items.Add(item);
                    }
                }
                else
                {
                    MessageBox.Show("Nemate konkurs.");
                }

            }
            
        }

        private void obrisi_konkurs_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count <= 0)
            {
                MessageBox.Show("Molimo vas odaberite konkurs.");
            }
            else
            {
                var item = listView1.SelectedItems[0];
                string s = item.SubItems[6].Text;
                var db = client.GetDatabase("posao");

                var collection = db.GetCollection<Konkurs>("konkurs");
                var filter = Builders<Konkurs>.Filter.Eq("_id", s);
                var result = collection.DeleteOne(filter);
                listView1.SelectedItems[0].Remove();
                MessageBox.Show("Uspesno ste obrisali konkurs");
            }
        }

        private void prikazi_civije_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count<=0)
            {
                MessageBox.Show("Molimo vas odaberite konkurs.");
            }
            else
            {
                var item1 = listView1.SelectedItems[0];
                string s = item1.SubItems[6].Text;
                var db = client.GetDatabase("posao");
                var collection = db.GetCollection<Konkurs>("konkurs");
                var collection1 = db.GetCollection<CV>("cv");
                var filter = Builders<Konkurs>.Filter.Eq("_id", s);
                var result = collection.Find(filter).ToList();

                if (result.Count != 0)
                {

                    string[] pom = result[0].cvId;

                    if (pom != null)
                    {
                        foreach (var x in pom)
                        {
                            var filter1 = Builders<CV>.Filter.Eq("studentId", x);
                            var result1 = collection1.Find(filter1).ToList();

                            if (result1.Count != 0)
                            {
                                string[] values = result1[0].obrazovanje;
                                string val = "";

                                for (int i = 0; i < values.Length; i++)
                                {
                                    if (i == values.Length - 1)
                                    {
                                        val += "" + values[i];
                                    }
                                    else
                                    {
                                        val += "" + values[i] + ",";
                                    }
                                }
                                string[] values1 = result1[0].vestine;
                                string val1 = "";

                                for (int i = 0; i < values1.Length; i++)
                                {
                                    if (i == values1.Length - 1)
                                    {
                                        val1 += "" + values1[i];
                                    }
                                    else
                                    {
                                        val1 += "" + values1[i] + ",";
                                    }
                                }
                                foreach (CV cv in result1)
                                {
                                    ListViewItem item = new ListViewItem(new string[] {cv.licneInformacije.punoIme,
                       cv.licneInformacije.datumRodjenja, cv.licneInformacije.adresa,
                       cv.licneInformacije.email,cv.licneInformacije.telefon,val,val1});

                                    listView2.Items.Add(item);
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Nema prijavljenih CV-jeva.");
                    }
                }

            }
        }
    }
}
